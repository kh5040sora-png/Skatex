from fastapi import FastAPI

from app.routes.events import router as events_router
from app.routes.orders import router as orders_router
from app.routes.webhooks import router as webhooks_router

app = FastAPI(title="Skatex Data Platform")


@app.get("/health")
def health() -> dict:
    return {"ok": True}


app.include_router(events_router)
app.include_router(orders_router)
app.include_router(webhooks_router)
