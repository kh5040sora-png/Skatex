from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db import get_db
from app.models import Event
from app.schemas import EventIn

router = APIRouter(prefix="/events", tags=["events"])


@router.post("")
def ingest_event(payload: EventIn, db: Session = Depends(get_db)) -> dict:
    event = Event(
        user_id=payload.user_id,
        session_id=payload.session_id,
        event_name=payload.event_name,
        event_ts=payload.event_ts,
        properties=payload.properties,
    )
    db.add(event)
    db.commit()
    return {"status": "accepted", "event_name": payload.event_name}
