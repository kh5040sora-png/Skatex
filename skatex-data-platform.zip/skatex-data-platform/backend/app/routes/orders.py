from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db import get_db
from app.models import Order, OrderItem
from app.schemas import OrderIn
from app.workers.queue import queue
from app.workers.tasks import process_order_created

router = APIRouter(prefix="/orders", tags=["orders"])


@router.post("")
def create_order(payload: OrderIn, db: Session = Depends(get_db)) -> dict:
    if not payload.items:
        raise HTTPException(status_code=400, detail="Order requires at least one item")

    total_cents = sum(item.qty * item.unit_price_cents for item in payload.items)

    order = Order(
        user_id=payload.user_id,
        status="created",
        total_cents=total_cents,
        currency=payload.currency,
    )
    db.add(order)
    db.flush()

    for item in payload.items:
        db.add(
            OrderItem(
                order_id=order.id,
                product_id=item.product_id,
                qty=item.qty,
                unit_price_cents=item.unit_price_cents,
            )
        )

    db.commit()
    queue.enqueue(process_order_created, str(order.id))

    return {
        "status": "created",
        "order_id": str(order.id),
        "total_cents": total_cents,
        "currency": payload.currency,
    }
