from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db import get_db
from app.models import WebhookLog
from app.schemas import WebhookIn
from app.workers.queue import queue
from app.workers.tasks import process_webhook

router = APIRouter(prefix="/webhooks", tags=["webhooks"])


@router.post("")
def ingest_webhook(payload: WebhookIn, db: Session = Depends(get_db)) -> dict:
    row = WebhookLog(
        provider=payload.provider,
        event_type=payload.event_type,
        payload=payload.payload,
        status="pending",
    )
    db.add(row)
    db.flush()
    db.commit()

    queue.enqueue(process_webhook, row.id)
    return {"status": "received", "webhook_log_id": row.id}
