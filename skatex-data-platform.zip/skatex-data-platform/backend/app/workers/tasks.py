from app.workers.queue import queue


def process_order_created(order_id: str) -> None:
    print(f"Processing order_created for {order_id}")
    # reserve inventory
    # send receipt
    # reconcile payment


def process_webhook(webhook_log_id: int) -> None:
    print(f"Processing webhook {webhook_log_id}")
    # validate provider event
    # update order/payment state


if __name__ == "__main__":
    worker = queue.connection
    print("Worker connected:", worker)
