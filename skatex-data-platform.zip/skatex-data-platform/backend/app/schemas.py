from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, Field


class EventIn(BaseModel):
    user_id: UUID | None = None
    session_id: str | None = None
    event_name: str
    event_ts: datetime
    properties: dict[str, Any] = Field(default_factory=dict)


class OrderItemIn(BaseModel):
    product_id: UUID
    qty: int
    unit_price_cents: int


class OrderIn(BaseModel):
    user_id: UUID
    items: list[OrderItemIn]
    currency: str = "USD"


class WebhookIn(BaseModel):
    provider: str
    event_type: str
    payload: dict[str, Any]
