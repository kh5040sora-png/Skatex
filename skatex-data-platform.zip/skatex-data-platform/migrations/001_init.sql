create extension if not exists "pgcrypto";

create table users (
  id uuid primary key default gen_random_uuid(),
  email text unique not null,
  status text not null default 'active',
  created_at timestamptz not null default now()
);

create table products (
  id uuid primary key default gen_random_uuid(),
  sku text unique not null,
  name text not null,
  category text,
  price_cents integer not null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id),
  status text not null,
  total_cents integer not null,
  currency text not null default 'USD',
  created_at timestamptz not null default now()
);

create table order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id) on delete cascade,
  product_id uuid not null references products(id),
  qty integer not null check (qty > 0),
  unit_price_cents integer not null
);

create table events (
  id bigserial primary key,
  user_id uuid,
  session_id text,
  event_name text not null,
  event_ts timestamptz not null,
  properties jsonb not null default '{}'::jsonb,
  received_at timestamptz not null default now()
);

create table webhook_logs (
  id bigserial primary key,
  provider text not null,
  event_type text not null,
  payload jsonb not null,
  status text not null default 'pending',
  received_at timestamptz not null default now()
);

create index idx_events_name_ts on events(event_name, event_ts);
create index idx_orders_created_at on orders(created_at);
