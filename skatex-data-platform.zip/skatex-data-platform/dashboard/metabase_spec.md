# Dashboard spec

## Executive
- Daily revenue
- Order count
- Purchase conversion rate
- Average order value

## Product
- Product views by SKU
- Add-to-cart rate
- Checkout conversion
- Top-selling products

## Operations
- Pending webhooks
- Failed orders
- Event ingestion volume
- Queue lag
