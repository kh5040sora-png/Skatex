from sqlalchemy import text

from app.db import SessionLocal


def fetch_incremental_events(limit: int = 10000) -> list[dict]:
    with SessionLocal() as db:
        rows = db.execute(
            text("""
                select id, user_id, session_id, event_name, event_ts, properties, received_at
                from events
                order by id asc
                limit :limit
            """),
            {"limit": limit},
        ).mappings().all()
        return [dict(r) for r in rows]


def main() -> None:
    rows = fetch_incremental_events()
    print(f"Fetched {len(rows)} rows for warehouse sync")
    # load rows into BigQuery or another warehouse here


if __name__ == "__main__":
    main()
