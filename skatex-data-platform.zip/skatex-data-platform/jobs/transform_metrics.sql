create or replace view mart_daily_kpis as
select
  date(event_ts) as day,
  count(distinct user_id) filter (where event_name = 'session_started') as dau,
  count(*) filter (where event_name = 'product_viewed') as product_views,
  count(*) filter (where event_name = 'add_to_cart') as add_to_cart,
  count(*) filter (where event_name = 'checkout_started') as checkouts,
  count(*) filter (where event_name = 'purchase_completed') as purchases
from events
group by 1;

create or replace view mart_daily_revenue as
select
  date(created_at) as day,
  count(*) as order_count,
  sum(total_cents) / 100.0 as revenue_usd
from orders
where status in ('paid', 'completed')
group by 1;
