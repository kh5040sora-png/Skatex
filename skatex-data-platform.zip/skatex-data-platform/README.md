# Skatex Data Platform

Starter repo for an API → Database → Processing → Dashboard pipeline.

## Quick start

```bash
cp .env.example .env
docker-compose up --build
make migrate
curl http://localhost:8000/health
```

## Services
- FastAPI backend
- PostgreSQL operational database
- Redis queue
- RQ-style worker placeholder
- Warehouse sync starter job
- Dashboard spec

## Recommended next steps
- Add Alembic migrations
- Implement a real RQ worker entrypoint
- Add idempotency keys for orders and webhooks
- Add webhook signature verification
- Load transformed data into BigQuery or your warehouse
