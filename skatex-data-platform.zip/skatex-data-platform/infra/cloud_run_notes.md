# Cloud Run notes

- Deploy the API container to Cloud Run
- Use Cloud SQL for PostgreSQL
- Use Memorystore or a managed queue alternative
- Run scheduled jobs with Cloud Scheduler
- Land analytics data in BigQuery
